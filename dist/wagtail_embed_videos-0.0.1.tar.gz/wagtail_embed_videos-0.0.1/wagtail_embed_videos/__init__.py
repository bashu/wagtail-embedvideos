default_app_config = 'wagtail_embed_videos.apps.WagtailEmbedVideosAppConfig'

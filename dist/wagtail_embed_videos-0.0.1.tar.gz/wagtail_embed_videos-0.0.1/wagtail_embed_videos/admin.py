from django.contrib import admin
from django.conf import settings
